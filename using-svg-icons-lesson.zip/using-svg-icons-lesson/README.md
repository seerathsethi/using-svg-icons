# Using SVG icons lesson starter

**Use Illustrator & Spritebot to generate some SVG icons and use them in a website.**

- Approx. completion time: 1 hour
- Deliverables: HTML, CSS, images
- Due: Before the end of class

This is the starter code for a step-by-step lesson. Each step is described in detail here:

### [**Follow the “Using SVG icons” step-by-step lesson ➔**](https://learn-the-web.algonquindesign.ca/courses/web-design-2/using-svg-icons/)

---

## Questions or concerns

If you run into problems completing the task ask the teacher in class or, if you’re working outside of class, **create an Issue on your repository and tag the teacher**.
